<div class="row">
	<div class="col-md-12">
		<section class="row">
			<div class="col-md-12">
				<h3><?= $chapitre->title; ?></h3>
				<article>
					<?= $chapitre->content; ?>
				</article>
			</div>
		</section>
		<section class="row mt-4">
			<div class="col-md-12">
				<hr>
				<h3 class="mb-4">Commentaires</h3>
				<?php
				if ($comments == null) {
					echo '<div class="alert alert-info col-md-12 text-center">Aucun commentaire publié</div>';
				} else {
					foreach ($comments as $value) { ?>
						<article>
							<div class="row">
								<h4 class="col-md-8 offset-md-1">
									<?= $value->name; ?> <span class="comment-date">le <?= $value->date; ?></span><a href="index.php?report&postId=<?= $postId;?>&commentId=<?= $value->id; ?>" class="small offset-md-1">Signaler</a>
								</h4>
							</div>
							<?= $value->content;?>
						</article>
						<?php
					}
				} ?>
			</div>
		</section>
		<section class="row mt-4">
			<div class="col-md-12">
				<hr>
				<h3 class="mb-4">Ajouter un commentaire</h3>
				<?php
				$action = 'index.php?p=chapitre&postId='.$chapitre->id;
				echo FormBuilder::newCommForm($action);
				?>
			</div>
		</section>
	</div>
</div>