<?php
class Autoloader{
	
	static function register() {
		spl_autoload_register(array(__CLASS__, 'autoload'));
	}

	static function autoload($class)
	{
		$classFile = ROOT.'model'.DIRECTORY_SEPARATOR.$class.'.php';
		if (!file_exists($classFile)) {
			$classFile = ROOT.'model'.DIRECTORY_SEPARATOR.'core'.DIRECTORY_SEPARATOR.$class.'.php';
		}		
		require $classFile;
	}

}